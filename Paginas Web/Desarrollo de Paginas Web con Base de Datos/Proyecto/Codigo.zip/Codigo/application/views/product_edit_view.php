<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product Edit</title>
    <link rel='stylesheet' href='http://<?=base_url();?>css/bootstrap.min.css'>

</head>
<body>
    <div class='container'>
        <div class="card  w-100">
            <div class="card-header">
                <h5 class='card-title'>Edit Product</h5>
            </div>
            <?=form_open('http://'.site_url('product/update'));?>

            <div class="card-body">
    <?php
        if(validation_errors() != false) {
            echo '<div class="alert alert-danger">';
            echo validation_errors();
            echo '</div>';
        }
        
        foreach($result as $row) {
            echo form_hidden('id', $row->id);  
            echo '<div class="form-group">';
            echo form_label('Name');            
            $data = array(
                'class'         => 'form-control',
                'maxlength'     => 50,
                'placeholder'   => 'Name'
            );         
            echo form_input('name', $row->name, $data);
            echo '</div>';

            echo '<div class="form-group">';
            echo form_label('Quantity');           
            $data = array(
                'class'         => 'form-control',
                'maxlength'     => 100,
                'placeholder'   => 'Quantity'
            );
            echo form_input('quantity', $row->quantity, $data);
            echo '</div>';

            echo '<div class="form-group">';
            echo form_label('Price');            
            $data = array(
                    'class'         => 'form-control',
                    'maxlength'     => 100,
                    'placeholder'   => '$'
            );            
            echo form_input('price', $row->price, $data);
            echo "</div>";
            ?>
        </div>
        <div class="card-footer text-right">
            <a class='btn btn-secondary' href='http://<?=site_url();?>/product'>Cancel</a>
            &nbsp;&nbsp;
            <input class='btn btn-primary' type='submit' value='Save'>
        </div>
            <?php                        
 
            echo form_close();            
        }
    ?>
        </div>
    </div>
</body>
</html>