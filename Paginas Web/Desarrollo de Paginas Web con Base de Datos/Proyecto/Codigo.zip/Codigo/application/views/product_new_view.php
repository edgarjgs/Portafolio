<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Product</title>
    <link rel='stylesheet' href='http://<?=base_url();?>css/bootstrap.min.css'>

</head>
<body>
    <div class='container'>
        <div class="card  w-100">
            <div class="card-header">
                <h5 class='card-title'>Add New Product</h5>
            </div>
            <div class="card-body">
    <?php
        if(validation_errors() != false) {
            echo '<div class="alert alert-danger">';
            echo validation_errors();
            echo '</div>';
        }
    ?>
    <form action='http://<?=site_url();?>/product/insert' method='POST'>
        
        <div class="form-group">
            <label>Name</label>
            <?php
                $data = array(
                    'class'         => 'form-control',
                    'maxlength'     => 50,
                    'placeholder'   => 'Name'
                );
                echo form_input('name','', $data);
            ?>
        </div>
        <div class="form-group">
            <label>Quantity</label>
            <?php
                $data = array(
                    /*     'type' => 'number', */
                    'class'         => 'form-control',
                    'maxlength'     => 100,
                    'placeholder'   => 'Quantity'
                );
                echo form_input('quantity','', $data);
            ?>
        </div>
        <div class="form-group">
            <label>Price</label>
            <?php
                $data = array(
                    'class'         => 'form-control',
                    'maxlength'     => 100,
                    'placeholder'   => '$'
                );
                echo form_input('price','', $data);
            ?>
        </div>
        </div>
        <div class="card-footer text-right">
            <a class='btn btn-secondary' href='http://<?=site_url();?>/product'>Cancel</a>
            &nbsp;&nbsp;
            <input class='btn btn-primary' type='submit' value='Save'>
        </div>
    </form>
            
        </div>
    </div>
</body>
</html> 