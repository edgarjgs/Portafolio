<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product</title>
    <link rel='stylesheet' href='http://<?=base_url();?>css/bootstrap.min.css'>
    <script>
        function chkDelete(urlRec) {
            if (confirm('Delete the record?')){
                location.href = urlRec;
            }            
        }
    </script>
</head>
<body>
    <div class='container'>

    <div class='card'>
        <div class='card-header'>
            <h5>Product List</h5>
        </div>
        <div class='card-body'>

        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                    <th class='text-center'>
                        <a class='btn btn-primary btn-sm' href='http://<?=site_url();?>/product/create/'>Add New</a>   
                    </th>
                </tr>
            </thead>
    <?php
       if (count($result) > 0) {
            foreach($result as $row) {                
                echo '<tr>';
                echo '<td>' . $row->id . '</td>';
                echo '<td>' . $row->name . '</td>';
                echo '<td>' . $row->quantity . '</td>';
                echo '<td>'.'$' . $row->price . '</td>';
                echo '<td class="text-center">';
                echo '<a class="btn btn-success btn-sm" href="http://' . site_url() . '/product/edit/';
                echo $row->id . '">';
                echo 'Edit</a>&nbsp;';

                echo '<a class="btn btn-danger btn-sm" onclick="chkDelete(' . "'http://" . site_url() . "/product/delete/";
                echo $row->id . "');" . '">';
                echo '<font color="white">';
                echo 'Delete</a></font>';
                echo '</td>';
                echo '</tr>';
            }
            echo '<tfooter>';
            echo '<th class="text-left" colspan="5">';
            echo 'Rows: ' . count($result);
            echo '</th>';
            echo '</tfooter>';
            echo '</table>';
        }
        else {
            echo '<div "alert alert-warning" role="alert">';
            echo 'Records Not Found!';
            echo '</div>';
        }
    ?>
        </div> <!-- Card Body --> 
    </div> <!-- CARD -->
</body>
</html>






