<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User Edit</title>
    <link rel='stylesheet' href='http://<?=base_url();?>css/bootstrap.min.css'>

</head>
<body>
    <div class='container'>
        <div class="card  w-100">
            <div class="card-header">
                <h5 class='card-title'>Edit User</h5>
            </div>
            <?=form_open('http://'.site_url('users/update'));?>

            <div class="card-body">
    <?php
        if(validation_errors() != false) {
            echo '<div class="alert alert-danger">';
            echo validation_errors();
            echo '</div>';
        }
        
        foreach($result as $row) {
            echo form_hidden('userid', $row->id);  
            echo '<div class="form-group">';
            echo form_label('User');            
            $data = array(
                'class'         => 'form-control',
                'maxlength'     => 100,
                'placeholder'   => 'ex. johndoe@mail.com'
            );         
            echo form_input('username', $row->username, $data);
            echo '</div>';
            echo '<div class="form-group">';
            echo form_label('Password');           
            $data = array(
                'class'         => 'form-control',
                'maxlength'     => 20,
                'placeholder'   => 'New Password'
            );
            echo form_password('passcode', $row->passcode, $data);
            echo '</div>';
            echo '<div class="form-group">';
            echo form_label('Confirm Password');            
            echo form_password('passconfirm', $row->passcode, $data);
            echo '</div>';
            echo '<div class="form-group">';
            echo form_label('Name');            
            $data = array(
                'class'         => 'form-control',
                'maxlength'     => 100,
                'placeholder'   => 'Johh Doe'
            );            
            echo form_input('name', $row->name, $data);
            echo "</div>";
            ?>
        </div>
        <div class="card-footer text-right">
            <a class='btn btn-secondary' href='http://<?=site_url();?>/users/getall'>Cancel</a>
            &nbsp;&nbsp;
            <input class='btn btn-primary' type='submit' value='Save'>
        </div>
            <?php                        

            echo form_close();            
        }
    ?>
        </div>
    </div>
</body>
</html>