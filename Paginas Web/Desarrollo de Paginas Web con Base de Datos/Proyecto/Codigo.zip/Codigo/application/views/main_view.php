<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Main</title>
    <link rel='stylesheet' href='http://<?=base_url();?>css/bootstrap.min.css'>
</head>
<body>
<div class='container'>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="#">
         <img src="http://<?=base_url()?>img/cover.png" width="140">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
         <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
            <a class="nav-link" href="http://<?=base_url()?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" id='product' href="http://<?=base_url()?>index.php/product/getall/">Inventory</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" id='users' href='http://<?=base_url()?>index.php/users/getall/'>Users</a>
            </li>
         </ul>
         <div class="form-inline my-2 my-lg-0">            
           <!-- <strong><?php echo $name_session;?></strong>
            &nbsp; -->
           <!--  <img src="http://< ?=base_url()?>img/user1.png" height="20" > -->
           <img src="http://<?=base_url()?>img/user.png" height="35" >
            &nbsp;&nbsp;
            <a class="btn btn-outline-primary my-2 my-sm-0" 
               href="logout.php">Logout</a>
         </div>         
      </div>
      </nav>
      <br>
     <div class='content'>
         <?php    
            $this->load->view($forma, $result);   
         ?>
      </div>
      </div>
   </div>        
</body>
</html>