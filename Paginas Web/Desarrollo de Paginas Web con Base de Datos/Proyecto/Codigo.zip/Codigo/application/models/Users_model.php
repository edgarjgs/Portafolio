<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {

    public function getusers() {
        $query = $this->db->get('admin');
        return $query->result();
    }

    public function getuser($uid) {
        $this->db->where('id', $uid);
        $query = $this->db->get('admin');
        return $query->result();
    }    

    public function insert($data) {
        $this->db->insert('admin', $data);
    }

    public function delete($uid) {
        $this->db->where('id', $uid);
        $this->db->delete('admin');
    }

    public function update($uid, $data) {
        $this->db->where('id', $uid);
        $this->db->update('admin', $data);
    }

}

/* End of file ModelName.php */
?>