<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class product_model extends CI_Model {

    public function getproduct() {
        $query = $this->db->get('product');
        return $query->result();
    }

    public function getprod($pid) {
        $this->db->where('id', $pid);
        $query = $this->db->get('product');
        return $query->result();
    }    

    public function insert($data) {
        $this->db->insert('product', $data);
    }

    public function delete($pid) {
        $this->db->where('id', $pid);
        $this->db->delete('product');
    }

    public function update($pid, $data) {
        $this->db->where('id', $pid);
        $this->db->update('product', $data);
    }

}

/* End of file ModelName.php */
?>