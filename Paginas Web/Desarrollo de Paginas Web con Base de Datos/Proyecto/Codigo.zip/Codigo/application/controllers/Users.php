<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    public function index()
    {
        return $this->getall();

    }

    public function getall() 
    {
        $data['result'] = $this->users_model->getusers();
        $data['forma'] = 'users_view';        
        return $this->load->view('main_view', $data);        
    }

    public function get($uid) {       
        $data['result'] = $this->users_model->getuser($uid);
        $data['forma'] = 'users_view';
        $this->load->view('main_view', $data);
    }

    public function create() {
        $data['forma'] = 'users_new_view';
        $data['result'] = null;
        $this->load->view('main_view', $data);
    }

    public function insert() {
        $this->form_validation->set_rules('uname', 'Username', 'required|valid_email|is_unique[admin.username]');
        $this->form_validation->set_rules('pwd', 'Password', 'required|min_length[5]|max_length[15]'); 
        $this->form_validation->set_rules('name', 'Name', 'required');        
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        }
        else
        {
            $data = array(
                'username' => $_POST['uname'],
                'passcode' => $_POST['pwd'],
                'name' => $_POST['name'],
            );
            $this->users_model->insert($data);
            $this->getall();
        }   
    }

    public function delete($uid) {
        $this->users_model->delete($uid);
        $this->getall();
    }

    public function edit($uid) {
        $data['forma'] = 'users_edit_view';
        $data['result'] = $this->users_model->getuser($uid);
        $this->load->view('main_view', $data);        
    }
    public function update() {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('passcode', 'Password', 'required|min_length[5]|max_length[15]');
        $this->form_validation->set_rules('passconfirm', 'Password Confirmation', 'required|matches[passcode]');
        $this->form_validation->set_rules('name', 'Name', 'required');   
        $uid = $_POST['userid'];
        if ($this->form_validation->run() == FALSE) {
            $this->edit($uid);
        }
        else {

            $data = array(
                'username' => $_POST['username'],
                'passcode' => $_POST['passcode'],
                'name' => $_POST['name']
            );
            $this->users_model->update($uid, $data);        
            $this->getall();
        }
    }

}

/* End of file Users.php */

?>