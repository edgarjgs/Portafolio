<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class product extends CI_Controller {

    public function index()
    {
        return $this->getall();

    }

    public function getall() 
    {
        $data['result'] = $this->product_model->getproduct();
        $data['forma'] = 'product_view';        
        return $this->load->view('main_view', $data);        
    }

    public function get($pid) {       
        $data['result'] = $this->product_model->getprod($pid);
        $data['forma'] = 'product_view';
        $this->load->view('main_view', $data);
    }

    public function create() {
        $data['forma'] = 'product_new_view';
        $data['result'] = null;
        $this->load->view('main_view', $data);
    }

    public function insert() {
        $this->form_validation->set_rules('name', 'Name', 'required|min_length[1]|max_length[50]');
        $this->form_validation->set_rules('quantity', 'Quantity', 'required|numeric');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');        
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        }
        else
        {
            $data = array(
                'name' => $_POST['name'],
                'quantity' => $_POST['quantity'],
                'price' => $_POST['price']
            );

            $this->product_model->insert($data);
            $this->getall();
        }   
    }

    public function delete($pid) {
        $this->product_model->delete($pid);
        $this->getall();
    }

    public function edit($pid) {
        $data['forma'] = 'product_edit_view';
        $data['result'] = $this->product_model->getprod($pid);
        $this->load->view('main_view', $data);        
    }
    public function update() {
        $this->form_validation->set_rules('name', 'Name', 'required|min_length[1]|max_length[50]');
        $this->form_validation->set_rules('quantity', 'Quantity', 'required|numeric');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');  
        $pid = $_POST['id'];
        if ($this->form_validation->run() == FALSE) {
            $this->edit($pid);
        }
        else {

            $data = array(
                'name' => $_POST['name'],
                'quantity' => $_POST['quantity'],
                'price' => $_POST['price']
            );
            $this->product_model->update($pid, $data);        
            $this->getall();
        }
    }

}

/* End of file Users.php */
?>