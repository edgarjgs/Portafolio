<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

    public function index()
    {
        $data['forma'] = 'users_view';
        $data['result'] = $this->users_model->getusers();        
        $this->load->view('main_view', $data);        
    }


}

/* End of file Main.php */
?>